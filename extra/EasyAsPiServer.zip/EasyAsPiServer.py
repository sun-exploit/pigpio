#!/usr/bin/env python

# EasyAsPiServer.py
# 2014-09-15
# Public Domain

import sys
import threading
import time

if sys.version[0] == '2':
   import SocketServer as socketserver
else:
   import socketserver

class EasyAsPiServer(threading.Thread):
   """
   A simple server which will execute commands depending on the url
   entered in a browser.
   """
   def __init__(self, callback, PORT=9654):
      """
      Instantiate with the callback to handle received requests and
      the port to listen on which defaults to 9654.

      Using a port number greater than 1024 allows you to run Python
      without root privileges.
      """
      threading.Thread.__init__(self)
      self.stop_request = False
      self.callback = callback
      self.h = self.MyTCPHandler
      self.h.callback = self._callback
      HOST="0.0.0.0"
      self.server = socketserver.TCPServer((HOST, PORT), self.h)
      self.daemon = True
      self.start()

   def stop_requested(self):
      """
      Returns True if the user has requested a server shutdown
      via the browser interface.
      """
      return self.stop_request

   def stop(self):
      """
      Stops the server.
      """
      self.server.shutdown()

   def _callback(self, msg):
      (stop, content, data) = self.callback(msg)
      if stop:
         self.stop_request = True
      return "HTTP/1.1 200 OK\r\nContent-type:" + content + "\r\n\r\n" + data

   def run(self):
      self.server.serve_forever()

   class MyTCPHandler(socketserver.BaseRequestHandler):
      def handle(self):
         self.data = self.request.recv(1024).strip()
         self.data = self.data.split("\n")
         self.data = self.data[0].split(" ")
         self.request.sendall(self.callback(self.data))

if __name__ == "__main__":

   import subprocess

   HDR="<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01//EN\"><html><body>"
   TLR="</body></html>\r\n"

   # This callback should be tailored to execute your commands.

   def callback(msg):

      stop = False
      content = "text/html"

      if len(msg) < 2:
         msg[1] = ""

      result = msg[1]

      # http://localhost:9654/stop
      if msg[1] == "/stop":
         stop = True
         result = "shutting down"

      # http://localhost:9654/temp
      elif msg[1] == "/temp":
         try:
            result = subprocess.check_output(["/opt/vc/bin/vcgencmd","measure_temp"])
         except:
            result = "Couldn't read temperature"

      # http://localhost:9654/whoami
      elif msg[1] == "/whoami":
         try:
            result = subprocess.check_output(["whoami"])
         except:
            result = "Couldn't run whoami"

      data = HDR + result + TLR

      return (stop, content, data)

   # Start the server.

   x = EasyAsPiServer(callback) # Listening port defaults to 9654.

   while True:

      if x.stop_requested(): # Stop the server upon browser request.
         x.stop()
         break

      time.sleep(1)

